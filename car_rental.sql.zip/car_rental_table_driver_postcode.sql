
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `driver_postcode`
--

CREATE TABLE `driver_postcode` (
  `postcode_id` int(10) UNSIGNED NOT NULL,
  `fk_driver_id` int(10) UNSIGNED NOT NULL,
  `postcode` int(10) NOT NULL,
  `city` varchar(50) COLLATE utf8_german2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_german2_ci;

--
-- Daten für Tabelle `driver_postcode`
--

INSERT INTO `driver_postcode` (`postcode_id`, `fk_driver_id`, `postcode`, `city`) VALUES
(1, 2, 1258, 'Graz'),
(3, 5, 2369, 'Linz');
