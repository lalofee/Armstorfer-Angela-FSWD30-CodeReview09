
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `online_reservation`
--

CREATE TABLE `online_reservation` (
  `reservation_id` int(10) UNSIGNED NOT NULL,
  `fk_driver_id` int(10) UNSIGNED NOT NULL,
  `fk_car_id` int(10) UNSIGNED NOT NULL,
  `date and time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_german2_ci;
