
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `driver`
--

CREATE TABLE `driver` (
  `driver_id` int(10) UNSIGNED NOT NULL,
  `user_name` varchar(50) COLLATE utf8_german2_ci NOT NULL,
  `first_name` varchar(50) COLLATE utf8_german2_ci NOT NULL,
  `last_name` varchar(50) COLLATE utf8_german2_ci NOT NULL,
  `streetname` varchar(50) COLLATE utf8_german2_ci NOT NULL,
  `streetnumber` varchar(50) COLLATE utf8_german2_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_german2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_german2_ci;

--
-- Daten für Tabelle `driver`
--

INSERT INTO `driver` (`driver_id`, `user_name`, `first_name`, `last_name`, `streetname`, `streetnumber`, `email`) VALUES
(1, 'manni', 'Manfred', 'Müller', 'Amselweg', '7', 'manni@mail.de'),
(2, 'annastasia', 'Alma', 'Mather', 'Bärenweg', '8', 'alma@webmail.at'),
(4, 'vogelbär', 'Viktor', 'Victory', 'Siegesstrasse', '111', 'sieg@sieg.de'),
(5, 'bärlimaus', 'Susanne', 'Sangender', 'Susiweg', '9', 'bärli@mai.com');
